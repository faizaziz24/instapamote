<main class="main">
<!-- Breadcrumb-->
<ol class="breadcrumb">
  <li class="breadcrumb-item">
    <a href="<?php echo base_url(); ?>admin/prices">Price</a>
  </li>
  <li class="breadcrumb-item active">Edit Price</li>
</ol>

<div class="container-fluid">
  <div class="animated fadeIn">
    <!-- /.card-->
    <div class="row">
      <!-- /.col-->
      <div class="col-lg-12">

	    <div class="card">
	      <div class="card-header">
	        <strong>Price</strong> Form</div>
	      <?php echo form_open('admin/prices/update'); ?>
	      <div class="card-body">
			  <input type="hidden" name="id" value="<?php echo $price['id']; ?>">
	          <div class="form-group row">
	            <label class="col-md-3 col-form-label" for="hf-name">Name</label>
	            <div class="col-md-9">
	              <input class="form-control" type="text" name="name" placeholder="Enter Name" value="<?php echo $price['name']; ?>">
	            </div>
	          </div>
	          <div class="form-group row">
	            <label class="col-md-3 col-form-label" for="hf-body">Body</label>
	            <div class="col-md-9">
	              <textarea  id="editor1" name="body" class="form-control" style="height: 200px;" placeholder="Enter Description"><?php echo $price['body']; ?></textarea>	              
	            </div>
	          </div>
	          <div class="form-group row">
	            <label class="col-md-3 col-form-label" for="hf-price">Price</label>
	            <div class="col-md-9">
	              <input class="form-control" type="text" name="price" placeholder="Enter Price" value="<?php echo $price['price']; ?>">
	            </div>
	          </div>
	          <div class="form-group row">
	          	<label class="col-md-3 col-form-label" for="hf-discount">Discount</label>
	            <div class="col-md-3">
	              <input class="form-control" type="text" name="discount" placeholder="Enter Discount" value="<?php echo $price['discount']; ?>">
	            </div>
	            <label class="col-md-3 col-form-label" for="hf-day">Day</label>
	            <div class="col-md-3">
	              <input class="form-control" type="text" name="day" placeholder="Enter Day" value="<?php echo $price['day']; ?>">
	            </div>	            
	          </div>
	          <div class="form-group row">
	          	<label class="col-md-3 col-form-label" for="hf-count">Count</label>
	            <div class="col-md-3">
	              <input class="form-control" type="text" name="count" placeholder="Enter Count" value="<?php echo $price['count']; ?>">
	            </div>
	            <label class="col-md-3 col-form-label" for="hf-point">Point</label>
	            <div class="col-md-3">
	              <input class="form-control" type="text" name="point" placeholder="Enter Point" value="<?php echo $price['point']; ?>">
	            </div>	            
	          </div>
	          <?php echo validation_errors(); ?>
	      </div>
	      <div class="card-footer">
	        <button class="btn btn-sm btn-primary" type="submit">
	          <i class="fa fa-dot-circle-o"></i> Submit</button>
	      </div>
	      <?php echo form_close(); ?>
	    </div>

      </div>
      <!-- /.col-->
    </div>
  </div>
</div>
</main>
</div>
<?php 
	class Prices extends CI_Controller{
		
		public function index(){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$data['title'] = 'Report Prices';

			$data['prices'] = $this->price_model->get_prices();

			$this->load->view('admin/templates/header', $data);
			$this->load->view('admin/templates/sidebar');
			$this->load->view('admin/prices/index', $data);
			$this->load->view('admin/templates/footer');
		}

		public function create(){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}
			
			$data['title'] = 'Create Price';

			$this->form_validation->set_rules('name', 'Name', 'required');
			$this->form_validation->set_rules('body', 'Body', 'required');
			$this->form_validation->set_rules('price', 'Price', 'required');
			$this->form_validation->set_rules('day', 'Day', 'required');
			$this->form_validation->set_rules('discount', 'Discount', 'required');
			$this->form_validation->set_rules('count', 'Count', 'required');
			$this->form_validation->set_rules('point', 'Point', 'required');


			if($this->form_validation->run() === FALSE){
				$this->load->view('admin/templates/header', $data);
				$this->load->view('admin/templates/sidebar');
				$this->load->view('admin/prices/create', $data);
				$this->load->view('admin/templates/footer');
			} else {
				$this->price_model->create();

				// Set message
				$this->session->set_flashdata('price_created', 'You are now created the price');

				redirect('admin/prices');
			}
		}

		public function edit($id){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$data['price'] = $this->price_model->get_prices($id);

			if(empty($data['price'])){
				show_404();
			}

			$data['title'] = 'Update Price';

			$this->load->view('admin/templates/header', $data);
			$this->load->view('admin/templates/sidebar');
			$this->load->view('admin/prices/edit', $data);
			$this->load->view('admin/templates/footer');
		}

		public function update(){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}
			
			$this->price_model->update();

			$this->session->set_flashdata('price_updated', 'Your price hasbeen updated');

			redirect('admin/prices');
		}

		// Delete Customer
		public function delete($id){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$this->price_model->delete_price($id);

			$this->session->set_flashdata('price_deleted', 'Your price has been deleted');

			redirect('admin/prices');
		}
	}

?>
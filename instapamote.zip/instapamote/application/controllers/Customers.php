<?php 
	class Customers extends CI_Controller{

		public function dashboard(){
			if(!$this->session->userdata('customer_logged_in')){
				redirect('customers/register');
			}

			$data['title'] = 'Dashboard Customer';

			$data['advertisements'] = $this->customer_model->get_advertisement();

			$this->load->view('templates/header', $data);
			$this->load->view('templates/navbar');
			$this->load->view('customers/dashboard', $data);
			$this->load->view('templates/footer');
		}

		public function register(){
			$data['title'] = 'Register Customer';

			$this->form_validation->set_rules('name', 'Name', 'required');
			$this->form_validation->set_rules('email', 'Email', 'required|callback_check_email_exists');
			$this->form_validation->set_rules('password', 'Password', 'required');
			$this->form_validation->set_rules('password2', 'Confirm Password', 'matches[password]');

			if($this->form_validation->run() === FALSE){
				$this->load->view('templates/header', $data);
				$this->load->view('templates/navbar');
				$this->load->view('customers/register', $data);
				$this->load->view('templates/footer');
			} else {
				$enc_password = md5($this->input->post('password'));

				$this->customer_model->register($enc_password);

				$this->session->set_flashdata('customer_registered', 'You are now registered and can log in');

				redirect('customers/register');
			}
		}

		// Log in customer
		public function login(){
			$data['title'] = 'Login Customer';

			$this->form_validation->set_rules('email', 'Email', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required');

			if($this->form_validation->run() === FALSE){
				$this->load->view('templates/header', $data);
				$this->load->view('templates/navbar');
				$this->load->view('customers/login', $data);
				$this->load->view('templates/footer');
			} else {
				
				// Get email
				$email = $this->input->post('email');
				// Get and encrypt the password
				$password = md5($this->input->post('password'));

				// Login customer
				$id_cus = $this->customer_model->login($email, $password);

				if($id_cus){
					// Create session
					$customer_data = array(
						'id_cus' => $id_cus,
						'customer_logged_in' => true
					);

					$this->session->set_userdata($customer_data);

					// Set message
					$this->session->set_flashdata('customer_loggedin', 'You are now logged in');

					redirect('customers/dashboard');
				} else {
					// Set message
					$this->session->set_flashdata('login_failed', 'Login is invalid');

					redirect('customers/login');
				}		
			}
		}

		// Log customer out
		public function logout(){
			// Unset customer data
			$this->session->unset_userdata('customer_logged_in');
			$this->session->unset_userdata('id_cus');
			$this->session->unset_userdata('name_cus');
			$this->session->unset_userdata('email_cus');


			// Set message
			$this->session->set_flashdata('customer_loggedout', 'You are now logged out');

			redirect('customers/login');
		}

		// create advertisement
		public function create(){
			if(!$this->session->userdata('customer_logged_in')){
				redirect('customers/register');
			}

			$data['prices'] = $this->price_model->get_prices();

			$data['title'] = 'Create Advertisement';

			$this->form_validation->set_rules('title', 'Title', 'required');
			$this->form_validation->set_rules('description', 'Description', 'required');

			if($this->form_validation->run() === FALSE){
				$this->load->view('templates/header', $data);
				$this->load->view('templates/navbar');
				$this->load->view('customers/create', $data);
				$this->load->view('templates/footer');
			} else {
				$config['upload_path'] = './assets/img/advertisements';
				$config['allowed_types'] = 'gif|jpg|png|GIF|JPG|PNG';
				$config['max_size'] = '2048';
				$config['max_width'] = '2000';
				$config['max_height'] = '2000';

				$this->load->library('upload', $config);

				if(!$this->upload->do_upload()){
					$errors = array('error' => $this->upload->display_errors());
					$post_image = 'noimage.jpg';
				} else {
					$data = array('upload_data' => $this->upload->data());
					$post_image = $_FILES['userfile']['name'];
				}

				$this->customer_model->create_advertisement($post_image);

				$this->session->set_flashdata('create_advertisement', 'You are advertised and can look it');

				redirect('customers/dashboard');
			}
		}

		// Check if email exists
		public function check_email_exists($email){
			$this->form_validation->set_message('check_email_exists', 'That email is taken. Please choose a different one');
			if($this->customer_model->check_email_exists($email)){
				return true;
			} else {
				return false;
			}
		}
	}
?>
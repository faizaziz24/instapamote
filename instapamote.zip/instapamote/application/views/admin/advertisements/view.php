<main class="main">
  <!-- Breadcrumb-->
  <ol class="breadcrumb">
    <li class="breadcrumb-item">Advertising</li>
    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>admin/advertisements/report">Report Advertisement</a></li>
    <li class="breadcrumb-item active">View Advertisement</li>
  </ol>

  <div class="container-fluid">
    <div class="animated fadeIn">
      <!-- /.card-->
      <div class="row">
        <!-- /.col-->
        <div class="col-sm-12">
          <div class="card">
            <div class="card-header"><i class="fa icon-layers"> <?php echo $advertisements['name_cus']; ?> - <?php echo $advertisements['title']; ?> (<?php echo $advertisements['create_at']; ?>)</i></div>
            <div class="col-sm-12">
              <div class="card-body">
                  Description : <?php echo $advertisements['description']; ?><br>
              </div>
              <div class="card-body">
                  Price : <?php echo $advertisements['price']; ?><br>
                  Day : <?php echo $advertisements['day']; ?><br>
                  Point : <?php echo $advertisements['point']; ?><br>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-12">

          <div class="card">
            <div class="card-header">
              <i class="fa icon-layers"></i>Report Advertisement Table</div>
            <div class="card-body">
              <div class="form-group row">
                <div class="col-md-12">
                </div>
              </div>
              <table class="table table-responsive-sm table-bordered">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Name Customer</th>
                    <th>URL</th>
                    <th>Created</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $count=0; foreach ($promotes as $promote) : ?>
                  <tr>
                    <td><?php echo ++$count; ?></td>
                    <td><?php echo $promote['name_ins']; ?></td>
                    <td><?php echo $promote['url']; ?></td>
                    <td><?php echo $promote['created_at']; ?></td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
              <ul class="pagination">
                <li class="page-item">
                  <a class="page-link" href="#">Prev</a>
                </li>
                <li class="page-item active">
                  <a class="page-link" href="#">1</a>
                </li>
                <li class="page-item">
                  <a class="page-link" href="#">2</a>
                </li>
                <li class="page-item">
                  <a class="page-link" href="#">3</a>
                </li>
                <li class="page-item">
                  <a class="page-link" href="#">4</a>
                </li>
                <li class="page-item">
                  <a class="page-link" href="#">Next</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!-- /.col-->
      </div>
    </div>
  </div>
</main>
</div>
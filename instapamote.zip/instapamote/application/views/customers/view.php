		<!-- start banner Area -->
		<section class="banner-area relative" id="home">	
			<div class="overlay overlay-bg"></div>
			<div class="container">
				<div class="row d-flex align-items-center justify-content-center">
					<div class="about-content col-lg-12">
						<h1 class="text-white">
							View			
						</h1>	
						<p class="text-white link-nav">View Advertisement</p>
					</div>											
				</div>
			</div>
		</section>
		<!-- End banner Area -->	

		<!-- Start feature-cat Area -->
		<section class="feature-cat-area pt-100 section-gap" id="category">
			<div class="container">
				<div class="row d-flex justify-content-center">
					<div class="menu-content pb-60 col-lg-10">
						<div class="row d-flex justify-content-center">
							<div class="col-lg-12">
								<div class="progress-table-wrap">
									<div class="progress-table">
										<div class="table-head">
											<div class="serial">ID</div>
											<div class="country">Title</div>
											<div class="country">Description</div>
											<div class="serial">Price</div>
											<div class="serial">Day</div>
											<div class="serial">Point</div>
											<div class="visit">Date</div>
										</div>
										<div class="table-row">
											<div class="serial"><?php echo $advertisements['id']; ?></div>
											<div class="country"> 
												<div class="col-lg-3 feat-img no-padding">
													<img src="<?php echo site_url(); ?>assets/img/advertisements/<?php echo $advertisements['photo']; ?>" alt="flag">
												</div>
												<div class="col-lg-9">
												<?php echo $advertisements['title']; ?>
												</div></div>
											<div class="country"><?php echo $advertisements['description']; ?></div>
											<div class="serial"><?php echo $advertisements['price']; ?></div>
											<div class="serial"><?php echo $advertisements['day']; ?></div>
											<div class="serial"><?php echo $advertisements['point']; ?></div>
											<div class="visit"><?php echo $advertisements['create_at']; ?></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row d-flex justify-content-center">
					<div class="menu-content pb-60 col-lg-10">
					<div class="row d-flex justify-content-center">
						<div class="col-lg-12">
							<div class="progress-table-wrap">
								<div class="progress-table">
									<div class="table-head">
										<div class="serial">ID</div>
										<div class="country">Name</div>
										<div class="country">URL</div>	
										<div class="serial">Action</div>
									</div>
									<?php $count=0; foreach ($promotes as $promote) : ?>
									<?php if($this->session->userdata('id_cus') == $promote['customer_id']): ?>
									<div class="table-row">
										
										<div class="serial"><?php echo ++$count; ?></div>
										<div class="country"><?php echo $promote['name_ins']; ?></div>
										<div class="country"><?php echo $promote['url']; ?></div>
										<div class="serial">
											<a class="ticker-btn" href="<?php echo base_url(); ?>advertisements/confirm/<?php echo $promote['instagrammer_id']; ?>">confirm</a>
											<a class="ticker-btn" href="<?php echo base_url(); ?>advertisements/delete/<?php echo $promote['instagrammer_id']; ?>">delete</a>
										</div>
									</div>
									<?php endif; ?>
									<?php endforeach; ?>
								</div>
							</div>
						</div>
					</div>
					</div>			
				</div>
			</div>
		</section>
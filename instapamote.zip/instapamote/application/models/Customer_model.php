<?php
	class Customer_model extends CI_Model{
		public function register($enc_password){
			$data = array(
				'name_cus' => $this->input->post('name'),
				'email_cus' => $this->input->post('email'),
                'password_cus' => $enc_password
			);
			return $this->db->insert('customers', $data);
		}

		// Log customer in
		public function login($email, $password){
			// Validate
			$this->db->where('email_cus', $email);
			$this->db->where('password_cus', $password);
			$this->db->where('is_status', 1);

			$result = $this->db->get('customers');

			if($result->num_rows() == 1){
				return $result->row(0)->id_cus;
			} else {
				return false;
			}
		}

		public function get_advertisement(){
			$query = $this->db->get('advertisements');
			return $query->result_array();
		}
		
		public function create_advertisement($post_image){
			$slug = url_title($this->input->post('title'));

			$data = array(
				'title' => $this->input->post('title'),
				'customer_id' => $this->session->userdata('id_cus'),
				'price_id' => $this->input->post('price_id'),
				'slug' => $slug,
				'description' => $this->input->post('description'),
				'photo' => $post_image
			);

			return $this->db->insert('advertisements', $data);
		}

		// Check email exists
		public function check_email_exists($email){
			$query = $this->db->get_where('customers', array('email_cus' => $email));
			if(empty($query->row_array())){
				return true;
			} else {
				return false;
			}
		}


		// Connect to database
		public function __construct(){
			$this->load->database();
		}

		public function get_customers($id = FALSE){
			if($id === FALSE){
				$query = $this->db->get('customers');
				return $query->result_array();
			}

			$query = $this->db->get_where('customers', array('id_cus' => $id));
			return $query->row_array();
			
		}

		public function update_customer($enc_password){

			$data = array(
				'email_cus' => $this->input->post('email'),
				'name_cus' => $this->input->post('name'),
				'password_cus' => $enc_password
			);

			$this->db->where('id_cus', $this->input->post('id'));
			return $this->db->update('customers', $data);
		}

		public function get_customers_new(){
			$this->db->order_by('id_cus');
			$query = $this->db->get_where('customers', array('is_status' => 0));
			return $query->result_array();
		}

		public function get_customers_all(){
			$this->db->order_by('id_cus');
			$query = $this->db->get_where('customers', array('is_status' => 1));
			return $query->result_array();
		}
		
		public function sum_customers_all(){
			$query = $this->db->get_where('customers', array('is_status' => 1));

			$data  = $query->num_rows();
			return $data;
		}

		// Create Customer
		public function create($enc_password){
			// Customers data array
			$data = array(
				'name_cus' => $this->input->post('name'),
				'email_cus' => $this->input->post('email'),
                'password_cus' => $enc_password
			);

			// Insert Customer
			return $this->db->insert('customers', $data);
		}

		// Update Customer
		public function active_customer($id){
			// Customer data array
			$data = array(
				'is_status' => 1
			);

			// Query Update Customer
			$this->db->where('id_cus', $id);
			return $this->db->update('customers', $data);
		}

		// Delete Customer
		public function delete_customer($id){

			//Delete Customer
			$this->db->where('id_cus', $id);
			$this->db->delete('customers');
			return true;
		}		
	}
<!-- start footer Area -->		
			<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-5  col-md-12">
							<div class="single-footer-widget">
								<h6>About Us</h6>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
								tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
								quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
								consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
								cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
								proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
							</div>
						</div>
						<div class="col-lg-3  col-md-12">
							<div class="single-footer-widget">
								<h6>Navigation Links</h6>
								<ul class="footer-nav">
									<li><a href="<?php echo base_url(); ?>">Home</a></li>
									<li><a href="<?php echo base_url(); ?>about">About</a></li>
									<li><a href="<?php echo base_url(); ?>price">Price</a></li>
									<li><a href="<?php echo base_url(); ?>contact">Contact</a></li>

							        <?php if($this->session->userdata('customer_logged_in')) : ?>
									<li><a href="<?php echo base_url(); ?>customers/dashboard">Dashboard</a></li>
									<li><a href="<?php echo base_url(); ?>customers/logout">Logout</a></li>
									<?php endif; ?>
									
									<?php if($this->session->userdata('instagrammer_logged_in')) : ?>
									<li><a href="<?php echo base_url(); ?>instagrammers/dashboard">Dashboard</a></li>
									<li><a href="<?php echo base_url(); ?>instagrammers/logout">Logout</a></li>
									<?php endif; ?>
								</ul>
							</div>
						</div>
						<div class="col-lg-4  col-md-12">
							<div class="single-footer-widget">
								<h6>Contact Us</h6>
								<ul class="footer-nav">
						            <li><i class="fa fa-map-marker"></i> Kepuh GK III/850 Klitren, Gondokusuman, Kota Yogyakarta, Daerah Istimewa Yogyakarta kodepos 55222</li>
						            <li><i class="fa fa-phone"></i> 082136549690</li>
						            <li><i class="fa fa-envelope-o"></i> instapamote@gmail.com</li>
						        </ul>
							</div>
						</div>						
					</div>

					<div class="row footer-bottom d-flex justify-content-between">
						<p class="col-lg-8 col-sm-12 footer-text m-0 text-white">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Faizal Fahmi Aziz</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						</p>
					</div>
				</div>
			</footer>
			<!-- End footer Area -->		

			<script src="<?php echo base_url(); ?>assets/js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="<?php echo base_url(); ?>assets/js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="<?php echo base_url(); ?>assets/js/easing.min.js"></script>			
			<script src="<?php echo base_url(); ?>assets/js/hoverIntent.js"></script>
			<script src="<?php echo base_url(); ?>assets/js/superfish.min.js"></script>	
			<script src="<?php echo base_url(); ?>assets/js/jquery.ajaxchimp.min.js"></script>
			<script src="<?php echo base_url(); ?>assets/js/jquery.magnific-popup.min.js"></script>
			<script src="<?php echo base_url(); ?>assets/js/owl.carousel.min.js"></script>		
			<script src="<?php echo base_url(); ?>assets/js/jquery.sticky.js"></script>
			<script src="<?php echo base_url(); ?>assets/js/jquery.nice-select.min.js"></script>
			<script src="<?php echo base_url(); ?>assets/js/parallax.min.js"></script>		
			<script src="<?php echo base_url(); ?>assets/js/mail-script.js"></script>	
			<script src="<?php echo base_url(); ?>assets/js/main.js"></script>
			<script src="<?php echo base_url(); ?>assets/js/ckeditor/ckeditor.js"></script>
			<script>
				CKEDITOR.replace('editor1');
			</script>
		</body>
	</html>
<?php
	class Price_model extends CI_Model{
		
		public function __construct(){
			$this->load->database();
		}

		public function get_prices($id = FALSE){
			if($id === FALSE){
				$query = $this->db->get('prices');
				return $query->result_array();
			}

			$query = $this->db->get('prices');
			return $query->row_array();
			
		}

		public function create(){
			$post_slug = url_title($this->input->post('name'));

			// Price data array
			$data = array(
				'name' => $this->input->post('name'),
				'post_slug' => $post_slug,
				'body' => $this->input->post('body'),
				'price' => $this->input->post('price'),
				'day' => $this->input->post('day'),
				'discount' => $this->input->post('discount'),
				'count' => $this->input->post('count'),
				'point' => $this->input->post('point')
			);

			// Insert Price
			return $this->db->insert('prices', $data);
		}

		public function update(){
			$post_slug = url_title($this->input->post('name'));

			// Customers data array
			$data = array(
				'name' => $this->input->post('name'),
				'post_slug' => $post_slug,
				'body' => $this->input->post('body'),
				'price' => $this->input->post('price'),
				'day' => $this->input->post('day'),
				'discount' => $this->input->post('discount'),
				'count' => $this->input->post('count'),
				'point' => $this->input->post('point')
			);

			// Insert Price
			$this->db->where('id', $this->input->post('id'));
			return $this->db->update('prices', $data);
		}

		// Delete Price
		public function delete_price($id){

			//Delete Price
			$this->db->where('id', $id);
			$this->db->delete('prices');
			return true;
		}
	}
?>
						<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row fullscreen d-flex align-items-center justify-content-center">
						<div class="banner-content col-lg-12">
							<h1 class="text-white">
								<span>Promote</span> Your Product & Event			
							</h1>
							<p class="text-white"> Join the founder who promote your products from each other everyday in local communities around the world</p>
						</div>											
					</div>
				</div>
			</section>
			<!-- End banner Area -->

			<!-- Start features Area -->
			<section class="features-area">
				<div class="container">
					<div class="row">
						<div class="col-lg-3 col-md-6">
							<div class="single-feature">
								<h4>Searching</h4>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing. 
								</p>
							</div>
						</div>
						<div class="col-lg-3 col-md-6">
							<div class="single-feature">
								<h4>Applying</h4>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing.
								</p>
							</div>
						</div>
						<div class="col-lg-3 col-md-6">
							<div class="single-feature">
								<h4>Reposting</h4>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing.
								</p>
							</div>
						</div>
						<div class="col-lg-3 col-md-6">
							<div class="single-feature">
								<h4>Notifications</h4>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing.
								</p>
							</div>
						</div>																		
					</div>
				</div>	
			</section>
			<!-- End features Area -->
			
			<!-- Start popular-post Area -->
			<section class="popular-post-area pt-100 section-gap">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="menu-content pb-60 col-lg-8">
							<div class="title text-center">
								<h1 class="mb-10">Top rated Product/Event posts</h1>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
								tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
								quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
								consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
								cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
								proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
							</div>
						</div>
					</div>
					<div class="row align-items-center">
						<div class="active-popular-post-carusel">
							<?php foreach ($advertisements as $advertisement) : ?>
							<div class="single-popular-post d-flex flex-row">
								<div class="single-rated">
									<h4><?php echo $advertisement['title']; ?></h4>
									<h6>Created on : <?php echo $advertisement['create_at']; ?></h6>
									<!-- Name area -->
									<!-- <h6>By : <?php echo $advertisement['name_cus']; ?></h6> -->
									<p>
										Description : <?php echo word_limiter($advertisement['description'], 50); ?>
									</p>
									<!-- Hidden area -->

									<!-- <p class="address"><span class="lnr lnr-map"></span>Day : <?php echo $advertisement['day']; ?> days</p>
									<p class="address"><span class="lnr lnr-database"></span> Count over : <?php echo $advertisement['count']; ?> posts</p>
									<p class="address"><span class="lnr lnr-cloud"></span> Point : <?php echo $advertisement['point']; ?> point</p> -->
								</div>
							</div>	
							<?php endforeach; ?>				
						</div>
					</div>
				</div>	
			</section>
			<!-- End popular-post Area -->

			<!-- Start callto-action Area -->
			<section class="callto-action-area section-gap" id="join">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="menu-content col-lg-9">
							<div class="title text-center">
								<h1 class="mb-10 text-white">Join us today without any hesitation</h1>
								<p class="text-white">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore  et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>
								<a class="primary-btn" href="<?php echo base_url(); ?>customers/register">I am a Customer</a>
								<a class="primary-btn" href="<?php echo base_url(); ?>instagrammer/register">I am a Instagrammer</a>
							</div>
						</div>
					</div>	
				</div>	
			</section>
			<!-- End calto-action Area -->
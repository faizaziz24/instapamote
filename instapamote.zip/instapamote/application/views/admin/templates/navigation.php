<main class="main">
  <!-- Breadcrumb-->
  <ol class="breadcrumb">
    <li class="breadcrumb-item">Dashboard</li>
  </ol>

  <div class="container-fluid">
    <div class="animated fadeIn">
      <!-- /.row-->
      <div class="row">
        <div class="col-12 col-lg-4">
          <div class="card">
            <div class="card-body p-3 d-flex align-items-center">
              <i class="fa fa-user bg-primary p-3 font-2xl mr-3"></i>
              <div>
                <div class="text-value-sm text-primary"><?php echo $sum_customers_all; ?></div>
                <div class="text-muted text-uppercase font-weight-bold small">Customers</div>
              </div>
            </div>
            <div class="card-footer px-3 py-2">
              <a class="btn-block text-muted d-flex justify-content-between align-items-center" href="<?php echo base_url(); ?>admin/customers/report">
                <span class="small font-weight-bold">View More</span>
                <i class="fa fa-angle-right"></i>
              </a>
            </div>
          </div>
        </div>
        <!-- /.col-->
        <div class="col-12 col-lg-4">
          <div class="card">
            <div class="card-body p-3 d-flex align-items-center">
              <i class="fa fa-user bg-info p-3 font-2xl mr-3"></i>
              <div>
                <div class="text-value-sm text-info"><?php echo $sum_instagrammers_all; ?></div>
                <div class="text-muted text-uppercase font-weight-bold small">Instagrammers</div>
              </div>
            </div>
            <div class="card-footer px-3 py-2">
              <a class="btn-block text-muted d-flex justify-content-between align-items-center" href="<?php echo base_url(); ?>admin/instagrammers/report">
                <span class="small font-weight-bold">View More</span>
                <i class="fa fa-angle-right"></i>
              </a>
            </div>
          </div>
        </div>
        <!-- /.col-->
        <div class="col-12 col-lg-4">
          <div class="card">
            <div class="card-body p-3 d-flex align-items-center">
              <i class="fa fa-book bg-warning p-3 font-2xl mr-3"></i>
              <div>
                <div class="text-value-sm text-warning"><?php echo $sum_advertisements_all; ?></div>
                <div class="text-muted text-uppercase font-weight-bold small">Advertisements</div>
              </div>
            </div>
            <div class="card-footer px-3 py-2">
              <a class="btn-block text-muted d-flex justify-content-between align-items-center" href="<?php echo base_url(); ?>admin/advertisements/report">
                <span class="small font-weight-bold">View More</span>
                <i class="fa fa-angle-right"></i>
              </a>
            </div>
          </div>
        </div>
        <!-- /.col-->
      </div>
      <!-- /.card-->
      <div class="row">
        <!-- /.col-->
        <div class="col-lg-6">
          <div class="card">
            <div class="card-header">
              <i class="fa fa-align-justify"></i> New Customer Table</div>
            <div class="card-body">
              <table class="table table-responsive-sm table-bordered">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Date registered</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $count=0; foreach ($customers as $customer) : ?>
                  <tr>
                    <td><?php echo ++$count; ?></td>
                    <td><?php echo $customer['name_cus']; ?></td>
                    <td><?php echo $customer['created_at']; ?></td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
              <ul class="pagination">
                <li class="page-item">
                  <a class="page-link" href="#">Prev</a>
                </li>
                <li class="page-item active">
                  <a class="page-link" href="#">1</a>
                </li>
                <li class="page-item">
                  <a class="page-link" href="#">Next</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!-- /.col-->

        <!-- /.col-->
        <div class="col-lg-6">
          <div class="card">
            <div class="card-header">
              <i class="fa fa-align-justify"></i> New Instagrammer Table</div>
            <div class="card-body">
              <table class="table table-responsive-sm table-bordered">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Date Registered</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $count=0; foreach ($instagrammers as $instagrammer) : ?>
                  <tr>
                    <td><?php echo ++$count; ?></td>
                    <td><?php echo $instagrammer['name_ins']; ?></td>
                    <td><?php echo $instagrammer['created_at']; ?></td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
              <ul class="pagination">
                <li class="page-item">
                  <a class="page-link" href="#">Prev</a>
                </li>
                <li class="page-item active">
                  <a class="page-link" href="#">1</a>
                </li>
                <li class="page-item">
                  <a class="page-link" href="#">Next</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!-- /.col-->
      </div>

      <!-- /.row-->
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <i class="fa fa-align-justify"></i> New Advertisement Table</div>
            <div class="card-body">
              <table class="table table-responsive-sm table-bordered">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Title</th>
                    <th>Price (Rp.)</th>
                    <th>Date Created</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $count=0; foreach ($advertisements as $advertisement) : ?>
                  <tr>
                    <td><?php echo ++$count; ?></td>
                    <td><?php echo $advertisement['name_cus']; ?></td>
                    <td><?php echo $advertisement['title']; ?></td>
                    <td><?php echo $advertisement['price']; ?></td>
                    <td><?php echo $advertisement['created_at']; ?></td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
              <ul class="pagination">
                <li class="page-item">
                  <a class="page-link" href="#">Prev</a>
                </li>
                <li class="page-item active">
                  <a class="page-link" href="#">1</a>
                </li>
                <li class="page-item">
                  <a class="page-link" href="#">Next</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!-- /.col-->

        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <i class="fa fa-align-justify"></i> New Promotes Table</div>
            <div class="card-body">
              <table class="table table-responsive-sm table-bordered">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Title</th>
                    <th>Name</th>
                    <th>URL</th>
                    <th>Date Created</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $count=0; foreach ($promotes as $promote) : ?>
                  <tr>
                    <td><?php echo ++$count; ?></td>
                    <td><?php echo $promote['title']; ?></td>
                    <td><?php echo $promote['name_ins']; ?></td>
                    <td><?php echo $promote['url']; ?></td>    
                    <td><?php echo $promote['created_at']; ?></td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
              <ul class="pagination">
                <li class="page-item">
                  <a class="page-link" href="#">Prev</a>
                </li>
                <li class="page-item active">
                  <a class="page-link" href="#">1</a>
                </li>
                <li class="page-item">
                  <a class="page-link" href="#">Next</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!-- /.col-->
      </div>
      <!-- /.row-->
    </div>
  </div>
</main>
</div>
<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Login			
							</h1>	
							<p class="text-white link-nav">Login Instagrammer</p>
						</div>											
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

			<!-- Start feature-cat Area -->
			<section class="feature-cat-area pt-100 section-gap" id="category">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="menu-content pb-60 col-lg-10">
							<div class="title text-center">
								<h1 class="mb-10">Login Instagrammer</h1>
								<p>Who are in extremely love with eco friendly system.</p>
							</div>
						</div>
					</div>						
					<div class="row d-flex justify-content-center">
						<div class="col-lg-8 col-md-8">
							<!-- Flash messages -->
						    <?php if($this->session->flashdata('login_failed')): ?>
						        <?php echo '<p class="alert alert-danger">'.$this->session->flashdata('login_failed').'</p>'; ?>
						    <?php endif; ?>

						    <!-- Flash messages -->
						    <?php if($this->session->flashdata('instagrammer_loggedout')): ?>
						        <?php echo '<p class="alert alert-success">'.$this->session->flashdata('instagrammer_loggedout').'</p>'; ?>
						    <?php endif; ?>

							<?php echo validation_errors(); ?>

							<?php echo form_open('instagrammers/login'); ?>
								<div class="mt-10">
									<input type="email" name="email" class="form-control" placeholder="Enter Email">
								</div>
								<div class="mt-10">
									<input type="password" name="password" class="form-control"  placeholder="Enter Password">
								</div>
								<div class="input-group-icon mt-40 text-center">
									<input type="submit" value="Login" class="genric-btn primary radius e-large">
								</div>
							<?php echo form_close(); ?>
					</div>
				</div>	
			</section>
			<!-- End feature-cat Area -->
<main class="main">
<!-- Breadcrumb-->
<ol class="breadcrumb">
  <li class="breadcrumb-item">Price</li>
  <div class="ml-auto">
      <a class="btn btn-sm btn-success" href="<?php echo base_url(); ?>admin/prices/create"><i class="fa fa-plus"></i> New Price</a>
  </div>
</ol>

<div class="container-fluid">
  <div class="animated fadeIn">
    <!-- /.card-->
    <div class="row">
      <!-- /.col-->
      <div class="col-lg-12">

        <div class="card">
          <div class="card-header">
            <i class="fa fa-puzzle"></i> Price Table</div>
          <div class="card-body">

              <!-- Flash messages -->
              <?php if($this->session->flashdata('price_created')): ?>
                  <?php echo '<p class="alert alert-success">'.$this->session->flashdata('price_created').'</p>'; ?>
              <?php endif; ?>

              <!-- Flash messages -->
              <?php if($this->session->flashdata('price_updated')): ?>
                  <?php echo '<p class="alert alert-success">'.$this->session->flashdata('price_updated').'</p>'; ?>
              <?php endif; ?>

              <!-- Flash messages -->
              <?php if($this->session->flashdata('price_deleted')): ?>
                  <?php echo '<p class="alert alert-danger">'.$this->session->flashdata('price_deleted').'</p>'; ?>
              <?php endif; ?>

            <table class="table table-responsive-sm table-bordered">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Name</th>
                  <th>Body</th>
                  <th>Price (Rp.)</th>
                  <th>Day</th>
                  <th>Discount</th>
                  <th>Count</th>
                  <th>Point</th>
                  <th>Created</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($prices as $price) : ?>
                <tr>
                  <td><?php echo $price['id']; ?></td>
                  <td><?php echo $price['name']; ?></td>
                  <td><?php echo $price['body']; ?></td>
                  <td><?php echo $price['price']; ?></td>
                  <td><?php echo $price['day']; ?></td>
                  <td><?php echo $price['discount']; ?></td>
                  <td><?php echo $price['count']; ?></td>
                  <td><?php echo $price['point']; ?></td>
                  <td><?php echo $price['created_at']; ?></td>
                  <td>
                    <a class="btn btn-sm btn-primary" href="<?php echo base_url(); ?>admin/prices/edit/<?php echo $price['id']; ?>"><i class="fa fa-edit"></i> Edit</a>
                    <a class="btn btn-sm btn-danger" href="<?php echo base_url(); ?>admin/prices/delete/<?php echo $price['id']; ?>"><i class="fa fa-ban"></i> Delete</a>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <!-- /.col-->
    </div>
  </div>
</div>
</main>
</div>
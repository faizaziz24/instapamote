<main class="main">
<!-- Breadcrumb-->
<ol class="breadcrumb">
  <li class="breadcrumb-item">Instagrammer</li>
  <li class="breadcrumb-item active">Report Instagrammer</li>
</ol>

<div class="container-fluid">
  <div class="animated fadeIn">
    <!-- /.card-->
    <div class="row">
      <!-- /.col-->
      <div class="col-lg-12">

        <div class="card">
          <div class="card-header">
            <i class="icon-book-open"></i> Report Instagrammer Table</div>
          <div class="card-body">

            <!-- Flash messages -->
              <?php if($this->session->flashdata('instagrammer_created')): ?>
                  <?php echo '<p class="alert alert-success">'.$this->session->flashdata('instagrammer_created').'</p>'; ?>
              <?php endif; ?>

              <?php if($this->session->flashdata('instagrammer_updated')): ?>
                  <?php echo '<p class="alert alert-success">'.$this->session->flashdata('instagrammer_updated').'</p>'; ?>
              <?php endif; ?>
              
            <table class="table table-responsive-sm table-bordered">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>URL Profile Instagram</th>
                  <th>Created</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <?php $count=0; foreach ($instagrammers as $instagrammer) : ?>
                <tr>
                  <td><?php echo ++$count; ?></td>
                  <td><?php echo $instagrammer['name_ins']; ?></td>
                  <td><?php echo $instagrammer['email_ins']; ?></td>
                  <td><?php echo $instagrammer['url_profile_ins']; ?></td>
                  <td><?php echo $instagrammer['created_at']; ?></td>
                  <td>
                    <a class="btn btn-sm btn-primary" href="<?php echo base_url(); ?>admin/instagrammers/edit/<?php echo $instagrammer['id_ins']; ?>"><i class="fa fa-edit"></i> Edit</a>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <!-- /.col-->
    </div>
  </div>
</div>
</main>
</div>
			<header id="header" id="home">
			    <div class="container">
			    	<div class="row align-items-center justify-content-between d-flex">
				      <div id="logo">
				        <a href="index.html"><img src="img/logo.png" alt="" title="" /></a>
				      </div>
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
						  	<li><a href="<?php echo base_url(); ?>">Home</a></li>
							<li><a href="<?php echo base_url(); ?>about">About</a></li>
							<li><a href="<?php echo base_url(); ?>price">Price</a></li>
							<li><a href="<?php echo base_url(); ?>contact">Contact</a></li>
							<?php if(!$this->session->userdata('customer_logged_in') and !$this->session->userdata('instagrammer_logged_in')) : ?>
							<li class="menu-has-children"><a href="<?php echo base_url(); ?>">Register</a>
					            <ul>
					            	<li><a href="<?php echo base_url(); ?>customers/register">Register Customer</a></li>
									<li><a href="<?php echo base_url(); ?>instagrammers/register">Register Instagrammers</a></li>
					            </ul>
					        </li>
					        <li class="menu-has-children"><a href="<?php echo base_url(); ?>">Login</a>
					            <ul>
					            	<li><a href="<?php echo base_url(); ?>customers/login">Login Customer</a></li>
									<li><a href="<?php echo base_url(); ?>instagrammers/login">Login Instagrammers</a></li>
					            </ul>
					        </li>
					        <?php endif; ?>
					        <?php if($this->session->userdata('customer_logged_in')) : ?>
					        <li class="menu-has-children"><a href="<?php echo base_url(); ?>">Profile</a>
					            <ul>
					            	<li><a href="<?php echo base_url(); ?>customers/create">New Advertising</a></li>
					            	<li><a href="<?php echo base_url(); ?>customers/edit">Edit Profile</a></li>
					            	<li><a href="<?php echo base_url(); ?>customers/dashboard">Dashboard</a></li>
									<li><a href="<?php echo base_url(); ?>customers/logout">Logout</a></li>
					            </ul>
					        </li>
							<?php endif; ?>
							<?php if($this->session->userdata('instagrammer_logged_in')) : ?>
							<li><a href="<?php echo base_url(); ?>advertisements/">Advertisement</a></li>
							<li class="menu-has-children"><a href="<?php echo base_url(); ?>">Profile</a>
					            <ul>
					            	<li><a href="<?php echo base_url(); ?>instagrammers/edit">Edit Profile</a></li>
					            	<li><a href="<?php echo base_url(); ?>instagrammers/dashboard">Dashboard</a></li>
									<li><a href="<?php echo base_url(); ?>instagrammers/logout">Logout</a></li>
					            </ul>
					        </li>
							<?php endif; ?>
				        </ul>
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header><!-- #header -->
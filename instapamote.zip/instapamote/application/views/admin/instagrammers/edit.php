<main class="main">
<!-- Breadcrumb-->
<ol class="breadcrumb">
  <li class="breadcrumb-item">Instagrammer</li>
  <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>admin/instagrammers/report">Report Instagrammer</a></li>
  <li class="breadcrumb-item active">Edit</li>
</ol>

<div class="container-fluid">
  <div class="animated fadeIn">
    <!-- /.card-->
    <div class="row">
      <!-- /.col-->
      <div class="col-lg-12">

	    <div class="card">
	      <div class="card-header">
	        <strong>Instagrammer</strong> Form</div>
	      <?php echo form_open('admin/instagrammers/update'); ?>
	      <div class="card-body">			
				<input type="hidden" name="id" value="<?php echo $instagrammer['id_ins']; ?>">
	          <div class="form-group row">
	            <label class="col-md-3 col-form-label" for="hf-email">Email</label>
	            <div class="col-md-9">
	              <input class="form-control" type="email" name="email" value="<?php echo $instagrammer['email_ins']; ?>" placeholder="Enter Email">
	            </div>
	          </div>
	          <div class="form-group row">
	            <label class="col-md-3 col-form-label" for="hf-email">Name</label>
	            <div class="col-md-9">
	              <input class="form-control" type="text" name="name" value="<?php echo $instagrammer['name_ins']; ?>" placeholder="Enter Name">
	            </div>
	          </div>
	          <div class="form-group row">
	            <label class="col-md-3 col-form-label" for="hf-email">URL Instagram</label>
	            <div class="col-md-9">
	              <input class="form-control" type="text" name="url" value="<?php echo $instagrammer['url_profile_ins']; ?>" placeholder="Enter Name">
	            </div>
	          </div>
	          <div class="form-group row">
	            <label class="col-md-3 col-form-label" for="hf-password">Password</label>
	            <div class="col-md-9">
	              <input class="form-control" type="password" name="password" value="<?php echo $instagrammer['password_ins']; ?>" placeholder="Enter Password">
	            </div>
	          </div>
	      </div>
	      <div class="card-footer">
	        <button class="btn btn-sm btn-primary" type="submit">
	          <i class="fa fa-dot-circle-o"></i> Submit</button>
	      </div>
	      <?php echo form_close(); ?>
	    </div>

      </div>
      <!-- /.col-->
    </div>
  </div>
</div>
</main>
</div>

		<!-- start banner Area -->
		<section class="banner-area relative" id="home">	
			<div class="overlay overlay-bg"></div>
			<div class="container">
				<div class="row d-flex align-items-center justify-content-center">
					<div class="about-content col-lg-12">
						<h1 class="text-white">
							Dashboard			
						</h1>	
						<p class="text-white link-nav">Dashboard Instagrammer</p>
					</div>											
				</div>
			</div>
		</section>
		<!-- End banner Area -->	

		<!-- Start feature-cat Area -->
		<section class="feature-cat-area pt-100 section-gap" id="category">
			<div class="container">
				<div class="row d-flex justify-content-center">
					<div class="menu-content pb-60 col-lg-10">
						<div class="title text-center">
						<!-- Flash messages -->
					    <?php if($this->session->flashdata('instagrammer_loggedin')): ?>
					        <?php echo '<p class="alert alert-success">'.$this->session->flashdata('instagrammer_loggedin').'</p>'; ?>
					    <?php endif; ?>
					    <?php if($this->session->flashdata('create_promoted')): ?>
					        <?php echo '<p class="alert alert-success">'.$this->session->flashdata('create_promoted').'</p>'; ?>
					    <?php endif; ?>
						</div>
					</div>
					<div class="row d-flex justify-content-center">
						<div class="col-lg-12">
							<div class="progress-table-wrap">
								<div class="progress-table">
									<div class="table-head">
										<div class="serial">#</div>
										<div class="country">Title</div>
										<div class="visit">Date</div>
										<div class="visit">Status</div>
									</div>
									<?php $count=0; foreach ($promotes as $promote) : ?>
										<?php if($this->session->userdata('id_ins') == $promote['instagrammer_id']): ?>
									<div class="table-row">
										<div class="serial"><?php echo ++$count; ?></div>
										<div class="country">
											<div class="col-lg-3 feat-img no-padding">
												<img src="<?php echo site_url(); ?>assets/img/advertisements/<?php echo $promote['photo']; ?>" alt="flag">
											</div>
											<div class="col-lg-9">
												<?php echo $promote['title']; ?>
											</div>
										</div>
										<div class="visit"><?php echo $promote['created_at']; ?></div>
										<div class="visit">
											<?php
												if ($promote['prm_status']==1) {
													echo "Confirm";
												}else{
													echo "On Progress";
												}
											?>
										</div>
									</div>
										<?php endif; ?>
									<?php endforeach; ?>
								</div>
							</div>
						</div>
					</div>
				</div>						
				
			</div>
		</section>
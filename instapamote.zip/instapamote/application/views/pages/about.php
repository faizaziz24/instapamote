<!-- start banner Area -->
<section class="banner-area relative" id="home">	
	<div class="overlay overlay-bg"></div>
	<div class="container">
		<div class="row d-flex align-items-center justify-content-center">
			<div class="about-content col-lg-12">
				<h1 class="text-white">
					About Us				
				</h1>	
				<p class="text-white link-nav">About Us</p>
			</div>											
		</div>
	</div>
</section>
<!-- End banner Area -->	
	
<!-- Start service Area -->
<section class="service-area section-gap" id="service">
	<div class="container">
		<div class="row d-flex justify-content-center">
			<div class="col-md-8 pb-40 header-text">
				<h1>Why Choose Us</h1>
				<p>
					Who are in extremely love with eco friendly system.
				</p>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-4 col-md-6">
				<div class="single-service">
					<h4><span class="lnr lnr-user"></span>Expert Technicians</h4>
					<p>
						Usage of the Internet is becoming more common due to rapid advancement of technology and power.
					</p>
				</div>
			</div>
			<div class="col-lg-4 col-md-6">
				<div class="single-service">
					<h4><span class="lnr lnr-license"></span>Professional Service</h4>
					<p>
						Usage of the Internet is becoming more common due to rapid advancement of technology and power.
					</p>								
				</div>
			</div>
			<div class="col-lg-4 col-md-6">
				<div class="single-service">
					<h4><span class="lnr lnr-phone"></span>Great Support</h4>
					<p>
						Usage of the Internet is becoming more common due to rapid advancement of technology and power.
					</p>								
				</div>
			</div>
		</div>
	</div>	
</section>
<!-- End service Area -->						

<?php 
	class Instagrammers extends CI_Controller{
		
		public function index(){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$data['title'] = 'New Instagrammer';

			$data['instagrammers'] = $this->instagrammer_model->get_instagrammers_new();

			$this->load->view('admin/templates/header', $data);
			$this->load->view('admin/templates/sidebar');
			$this->load->view('admin/instagrammers/index', $data);
			$this->load->view('admin/templates/footer');
		}

		public function report(){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$data['title'] = 'Report Instagrammer';

			$data['instagrammers'] = $this->instagrammer_model->get_instagrammers_all();

			$this->load->view('admin/templates/header', $data);
			$this->load->view('admin/templates/sidebar');
			$this->load->view('admin/instagrammers/report', $data);
			$this->load->view('admin/templates/footer');
		}

		public function create(){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$data['title'] = 'Create Instagrammer';

			$this->form_validation->set_rules('name', 'Name', 'required');
			$this->form_validation->set_rules('email', 'Email', 'required|callback_check_email_exists');
			$this->form_validation->set_rules('url', 'Url Profile', 'required|callback_check_url_exists');
			$this->form_validation->set_rules('password', 'Password', 'required');
			$this->form_validation->set_rules('password2', 'Confirm Password', 'matches[password]');


			if($this->form_validation->run() === FALSE){
				$this->load->view('admin/templates/header', $data);
				$this->load->view('admin/templates/sidebar');
				$this->load->view('admin/instagrammers/create', $data);
				$this->load->view('admin/templates/footer');
			} else {
				// Encrypt password
				$enc_password = md5($this->input->post('password'));

				$this->instagrammer_model->create($enc_password);

				// Set message
				$this->session->set_flashdata('instagrammer_created', 'You are now created');

				redirect('admin/instagrammers');
			}
		}

		public function edit($id){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$data['instagrammer'] = $this->instagrammer_model->get_instagrammers($id);

			if(empty($data['instagrammer'])){
				show_404();
			}

			$data['title'] = 'Update Instagrammer';

			$this->form_validation->set_rules('name', 'Name', 'required');
			$this->form_validation->set_rules('email', 'Email', 'required');
			$this->form_validation->set_rules('url', 'URL Instagram', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required');

			$this->load->view('admin/templates/header', $data);
			$this->load->view('admin/templates/sidebar');
			$this->load->view('admin/instagrammers/edit', $data);
			$this->load->view('admin/templates/footer');

		}

		public function update(){
			// Check login
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$enc_password = md5($this->input->post('password'));

			$this->instagrammer_model->update_instagrammer($enc_password);

			// Set message
			$this->session->set_flashdata('instagrammer_updated', 'Your instagrammer has been updated');

			redirect('admin/instagrammers/report');
		}

		// Check if email exists
		public function check_email_exists($email){
			$this->form_validation->set_message('check_email_exists', 'That email is taken. Please choose a different one');
			if($this->instagrammer_model->check_email_exists($email)){
				return true;
			} else {
				return false;
			}
		}

		// Check if url profile exists
		public function check_url_exists($url){
			$this->form_validation->set_message('check_url_exists', 'That url profile is taken. Please choose a different one');
			if($this->instagrammer_model->check_url_exists($url)){
				return true;
			} else {
				return false;
			}
		}

		// Active Instagrammer
		public function active($id){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}
			
			$this->instagrammer_model->active_instagrammer($id);

			// Set message
			$this->session->set_flashdata('instagrammer_actived', 'Your instagrammer has been actived');

			redirect('admin/instagrammers');
		}

		// Delete Instagrammer
		public function delete($id){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$this->instagrammer_model->delete_instagrammer($id);

			// Set message
			$this->session->set_flashdata('instagrammer_deleted', 'Your instagrammer has been deleted');

			redirect('admin/instagrammers');
		}
	}

?>
<main class="main">
  <!-- Breadcrumb-->
  <ol class="breadcrumb">
    <li class="breadcrumb-item">Advertising</li>
    <li class="breadcrumb-item active">Data Advertisement</li>
  </ol>

  <div class="container-fluid">
    <div class="animated fadeIn">
      <!-- /.card-->
      <div class="row">
        <!-- /.col-->
        <div class="col-lg-12">

          <div class="card">
            <div class="card-header">
              <i class="fa icon-layers"></i> Advertisement Table</div>
            <div class="card-body">
              
              <!-- Flash messages -->
              <?php if($this->session->flashdata('advertisement_actived')): ?>
                  <?php echo '<p class="alert alert-success">'.$this->session->flashdata('advertisement_actived').'</p>'; ?>
              <?php endif; ?>

              <!-- Flash messages -->
              <?php if($this->session->flashdata('advertisement_deleted')): ?>
                  <?php echo '<p class="alert alert-success">'.$this->session->flashdata('advertisement_deleted').'</p>'; ?>
              <?php endif; ?>

              <table class="table table-responsive-sm table-bordered">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Name Customer</th>
                    <th>Title</th>
                    <th>Price (Rp.)</th>
                    <th>Created</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $count=0; foreach ($advertisements as $advertisement) : ?>
                  <tr>
                    <td><?php echo ++$count; ?></td>
                    <td><?php echo $advertisement['name_cus']; ?></td>
                    <td><?php echo $advertisement['title']; ?></td>
                    <td><?php echo $advertisement['price']; ?></td>
                    <td><?php echo $advertisement['created_at']; ?></td>
                    <td>
                      <a class="btn btn-sm btn-primary" href="<?php echo base_url(); ?>admin/advertisements/active/<?php echo $advertisement['slug']; ?>"><i class="icons cui-wrench"></i> Active</a>
                      <a class="btn btn-sm btn-danger" href="<?php echo base_url(); ?>admin/advertisements/delete/<?php echo $advertisement['slug']; ?>"><i class="fa fa-ban"></i> Delete</a>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <!-- /.col-->
      </div>
    </div>
  </div>
</main>
</div>
    <div class="app-body">
      <div class="sidebar">
        <nav class="sidebar-nav">
          <ul class="nav">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url(); ?>admin/dashboard">
                <i class="nav-icon icon-speedometer"></i> Dashboard
              </a>
            </li>
            <li class="nav-item nav-dropdown">
              <a class="nav-link nav-dropdown-toggle">
                <i class="nav-icon icon-user"></i> Customer</a>
              <ul class="nav-dropdown-items">
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo base_url(); ?>admin/customers">
                    <i class="nav-icon icon-user"></i> Data Customer</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo base_url(); ?>admin/customers/report">
                    <i class="nav-icon icon-book-open"></i> Report Customer</a>
                </li>
              </ul>
            </li>
            <li class="nav-item nav-dropdown">
              <a class="nav-link nav-dropdown-toggle">
                <i class="nav-icon icon-user"></i> Instagrammer</a>
              <ul class="nav-dropdown-items">
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo base_url(); ?>admin/instagrammers">
                    <i class="nav-icon icon-user"></i> Data Instagrammer</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo base_url(); ?>admin/instagrammers/report">
                    <i class="nav-icon icon-book-open"></i> Report Instagrammer</a>
                </li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url(); ?>admin/prices">
                <i class="nav-icon icon-puzzle"></i> Pricing
              </a>
            </li>
            <li class="nav-item nav-dropdown">
              <a class="nav-link nav-dropdown-toggle">
                <i class="nav-icon icon-layers"></i> Promoting</a>
              <ul class="nav-dropdown-items">
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo base_url(); ?>admin/advertisements">
                    <i class="nav-icon icon-layers"></i> Data Promotion</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo base_url(); ?>admin/advertisements/report">
                    <i class="nav-icon icon-book-open"></i> Report Promotion</a>
                </li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url(); ?>admin/logout">
                <i class="nav-icon icon-logout"></i> Logout
              </a>
            </li>
          </ul>
        </nav>
        <button class="sidebar-minimizer brand-minimizer" type="button"></button>
      </div>
<?php
	class Instagrammer_model extends CI_Model{
		public function register($enc_password){
			// Instagrammer data array
			$data = array(
				'name_ins' => $this->input->post('name'),
				'email_ins' => $this->input->post('email'),
				'url_profile_ins'=> $this->input->post('url'),
                'password_ins' => $enc_password
			);

			// Insert instagrammer
			return $this->db->insert('instagrammers', $data);
		}

		// Log instagrammer in
		public function login($email, $password){
			// Validate
			$this->db->where('email_ins', $email);
			$this->db->where('password_ins', $password);
			$this->db->where('is_status', 1);

			$result = $this->db->get('instagrammers');

			if($result->num_rows() == 1){
				return $result->row(0)->id_ins;
			} else {
				return false;
			}
		}

		// Check email exists
		public function check_email_exists($email){
			$query = $this->db->get_where('instagrammers', array('email_ins' => $email));
			if(empty($query->row_array())){
				return true;
			} else {
				return false;
			}
		}

		// Check url profile exists
		public function check_url_exists($url){
			$query = $this->db->get_where('instagrammers', array('url_profile_ins' => $url));
			if(empty($query->row_array())){
				return true;
			} else {
				return false;
			}
		}

		// Connect to database
		public function __construct(){
			$this->load->database();
		}

		public function get_instagrammers($id = FALSE){
			if($id === FALSE){
				$query = $this->db->get('instagrammers');
				return $query->result_array();
			}

			$query = $this->db->get_where('instagrammers', array('id_ins' => $id));
			return $query->row_array();
			
		}

		public function update_instagrammer($enc_password){

			$data = array(
				'name_ins' => $this->input->post('name'),
				'email_ins' => $this->input->post('email'),
				'url_profile_ins' => $this->input->post('url'),
				'password_ins' => $enc_password
			);

			$this->db->where('id_ins', $this->input->post('id'));
			return $this->db->update('instagrammers', $data);
		}

		public function get_instagrammers_new(){
			$this->db->order_by('id_ins');
			$query = $this->db->get_where('instagrammers', array('is_status' => 0));
			return $query->result_array();
		}

		public function get_instagrammers_all(){
			$this->db->order_by('id_ins');
			$query = $this->db->get_where('instagrammers', array('is_status' => 1));
			return $query->result_array();
		}

		public function sum_instagrammers_all(){
			$query = $this->db->get_where('instagrammers', array('is_status' => 1));

			$data  = $query->num_rows();
			return $data;
		}

		public function create($enc_password){
			// Instagrammer data array
			$data = array(
				'name_ins' => $this->input->post('name'),
				'email_ins' => $this->input->post('email'),
				'url_profile_ins'=> $this->input->post('url'),
                'password_ins' => $enc_password
			);

			// Insert instagrammer
			return $this->db->insert('instagrammers', $data);
		}

		// Update Instagrammer
		public function active_instagrammer($id){
			// Instagrammer data array
			$data = array(
				'is_status' => 1
			);

			// Query Update Instagrammer
			$this->db->where('id_ins', $id);
			return $this->db->update('instagrammers', $data);
		}

		// Delete Customer
		public function delete_instagrammer($id){

			//Delete Customer
			$this->db->where('id_ins', $id);
			$this->db->delete('instagrammers');
			return true;
		}

		public function get_promote(){
			$query = $this->db->get('promotes');
			return $query->result_array();
		}

		public function get_promotes_all(){
			$this->db->order_by('promotes.id', 'DESC');

			$this->db->join('advertisements', 'promotes.advertisement_id = advertisements.id');
			$this->db->join('instagrammers', 'instagrammers.id_ins = promotes.instagrammer_id');
			$this->db->join('prices', 'prices.id = advertisements.price_id');

			$query = $this->db->get_where('promotes');
			return $query->result_array();
		}
	}
?>
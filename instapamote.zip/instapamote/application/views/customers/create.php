<!-- start banner Area -->
<section class="banner-area relative" id="home">	
	<div class="overlay overlay-bg"></div>
	<div class="container">
		<div class="row d-flex align-items-center justify-content-center">
			<div class="about-content col-lg-12">
				<h1 class="text-white">
					Create Advertising			
				</h1>	
				<p class="text-white link-nav"><a href="<?php echo base_url(); ?>customers/dashboard"> Dashboard</a></a>  <span class="lnr lnr-arrow-right"></span> Create</p>
			</div>											
		</div>
	</div>
</section>
<!-- End banner Area -->	
	
<!-- Start price Area -->
<section class="price-area section-gap" id="price">
	<div class="container">				
		<div class="row d-flex justify-content-center">
			<div class="col-lg-8" style="margin-bottom: 30px;">
				<div class="container">	
				<?php echo validation_errors(); ?>								
					<ul class="lists">
						<?php echo form_open_multipart('customers/create'); ?>
						<div class="form-group">
							<input type="text" name="title" placeholder="Title" class="form-control">
						</div>									
						<div class="form-group">
							<select name="price_id" class="form-control">
								<?php foreach ($prices as $price) : ?>
									<option value="<?php echo $price['id']; ?>"><?php echo $price['name']; ?></option>
								<?php endforeach; ?>	
							</select>
						</div>
						<div class="form-group">
							<input type="file" name="userfile" size="20" class="form-control">
						</div>
						<div class="form-group">
							<textarea id="editor1" name="description" class="form-control" style="height: 200px;" placeholder="Description"></textarea>
						</div>
						<div class="input-group-icon mt-40 text-center">
							<input type="submit" value="Submit" class="genric-btn primary radius e-large">
						</div>
						<?php echo form_close(); ?>
					</ul>
				</div>
			</div>			
		</div>
	</div>	
</section>
<!-- End price Area -->
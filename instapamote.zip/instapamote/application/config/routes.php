<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['admin'] = 'admin/login';

$route['prices'] = 'prices/index';

$route['advertisements'] = 'advertisements/index';

$route['advertisements/(:any)'] = 'advertisements/create/$1';

$route['customers/view/(:any)'] = 'customers/view//$1';

$route['admin/advertisements/report/(:any)'] = 'admin/advertisements/report/$1';

$route['default_controller'] = 'pages/view';
$route['(:any)'] = 'pages/view/$1';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

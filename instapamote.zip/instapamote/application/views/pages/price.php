<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Pricing Plan				
							</h1>	
							<p class="text-white link-nav">Pricing Plan</p>
						</div>											
					</div>
				</div>
			</section>
			<!-- End banner Area -->	
				
	<!-- Start price Area -->
	<section class="price-area section-gap" id="price">
		<div class="container">
			<div class="row d-flex justify-content-center">
				<div class="menu-content pb-60 col-lg-8">
					<div class="title text-center">
						<h1 class="mb-10">Choose the best pricing for you</h1>
						<p>Who are in extremely love with eco friendly system.</p>
					</div>
				</div>
			</div>						
			<div class="row">
				<?php foreach ($prices as $price) : ?>
				<div class="col-lg-4">
					<div class="single-price no-padding">
						<div class="price-top">
							<h4><?php echo $price['name']; ?></h4>
						</div>
						<div class="container">
							<ul class="lists">
								<li><?php echo $price['body']; ?></li>
								<li><?php echo $price['day']; ?> day</li>
								<li>disc. <?php echo $price['discount']; ?>%</li>
							</ul>
						</div>
						<div class="price-bottom">
							<div class="price-wrap d-flex flex-row justify-content-center">
								<span class="price">Rp </span><h1> <?php echo $price['price']; ?></h1>
							</div>
						</div>
					</div>
				</div>
				<?php endforeach; ?>					
			</div>
		</div>	
	</section>
	<!-- End price Area -->
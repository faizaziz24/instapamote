<?php 
	class Pages extends CI_Controller{
		
		public function view($page = 'home'){
			if(!file_exists(APPPATH.'views/pages/'.$page.'.php')){
				show_404();
			}

			$data['title'] = ucfirst($page);

			$data['advertisements'] = $this->advertisement_model->get_advertisements();
			$data['prices'] = $this->price_model->get_prices();

			$this->load->view('templates/header', $data);
			$this->load->view('templates/navbar');
			$this->load->view('pages/'.$page, $data);
			$this->load->view('templates/footer');
		}
	}

?>
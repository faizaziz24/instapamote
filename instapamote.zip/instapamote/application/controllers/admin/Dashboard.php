<?php 
	class Dashboard extends CI_Controller{
		
		public function index(){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$data['sum_customers_all'] = $this->customer_model->sum_customers_all();
			$data['customers'] = $this->customer_model->get_customers_new();

			$data['sum_instagrammers_all'] = $this->instagrammer_model->sum_instagrammers_all();
			$data['instagrammers'] = $this->instagrammer_model->get_instagrammers_new();

			$data['sum_advertisements_all'] = $this->advertisement_model->sum_advertisements_all();
			$data['advertisements'] = $this->advertisement_model->get_advertisements_new();
			$data['promotes'] = $this->advertisement_model->get_promotes_new();

			$data['title'] = 'Home Admin';

			$this->load->view('admin/dashboard', $data);
		}
	}

?>
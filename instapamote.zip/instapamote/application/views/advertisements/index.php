
			<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Advertisement category				
							</h1>	
							<p class="text-white link-nav">Advertisements</p>
						</div>											
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

			<!-- Start post Area -->
			<section class="post-area section-gap">
				<div class="container">
					<div class="row justify-content-center d-flex">
						<div class="col-lg-8 post-list">
							<!-- Flash messages -->
						    <?php if($this->session->flashdata('create_price')): ?>
						        <?php echo '<p class="alert alert-success">'.$this->session->flashdata('create_price').'</p>'; ?>
						    <?php endif; ?>

							<?php foreach ($advertisements as $advertisement) : ?>
							<div class="single-post d-flex flex-row">
								<div class="col-lg-3 feat-img no-padding" style="margin-right: 15px;">
									<img src="<?php echo site_url(); ?>assets/img/advertisements/<?php echo $advertisement['photo']; ?>" alt="">
								</div>
								<div class="col-lg-9">
									<div class="details">
										<div class="title d-flex flex-row justify-content-between">
											<div class="titles">
												<h4><?php echo $advertisement['title']; ?></h4>
												<h6>Created on : <?php echo $advertisement['create_at']; ?></h6>
												<h6>By : <?php echo $advertisement['name_cus']; ?></h6>	
											</div>
											<ul class="btns">
												<li><a href="<?php echo base_url(); ?>advertisements/create/<?php echo $advertisement['id']; ?>">Apply</a></li>
											</ul>
										</div>
										<p>
											Description : <?php echo word_limiter($advertisement['description'], 50); ?>
										</p>
									</div>
								</div>
							</div>
							<?php endforeach; ?>	
						</div>
						<div class="col-lg-4 sidebar">
							<div class="single-slidebar">
								<div class="titles">
									<a href="single.html"><h4>Search Title</h4></a>
									<p>
									Search for promotion the product/event
									</p>				
								</div>
								<form action="#">
									<div class="mt-10">
										<input type="text" name="first_name" placeholder="Name">
										<input type="submit" value="Login" class="genric-btn primary radius medium">
									</div>
								</form>
							</div>
							<div class="single-widget category-widget">
								<h4 class="title">Post Archive</h4>
								<ul>
									<li><a href="#" class="justify-content-between align-items-center d-flex"><h6>Dec '18</h6> <span>37</span></a></li>
								</ul>
							</div>			
						</div>
					</div>
				</div>
			</section>
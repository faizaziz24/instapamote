<?php
	class Advertisement_model extends CI_Model{
		
		public function __construct(){
			$this->load->database();
		}

		public function get_advertisement_promote($id = FALSE){

			if($id === FALSE){
				$this->db->order_by('advertisements.id', 'DESC');

				$this->db->join('customers', 'customers.id_cus = advertisements.customer_id');

				$query = $this->db->get_where('advertisements', array('ads_status' => 1));
				return $query->result_array();
			}

			$this->db->join('customers', 'customers.id_cus = advertisements.customer_id');

			$query = $this->db->get_where('advertisements', array('ads_status' => 1,'id' => $id));
			return $query->row_array();
		}

		public function get_advertisements($slug = FALSE){
			if($slug === FALSE){
				$this->db->order_by('advertisements.id', 'DESC');
				
				$this->db->join('prices', 'prices.id = advertisements.price_id');
				$this->db->join('customers', 'customers.id_cus = advertisements.customer_id');

				$query = $this->db->get('advertisements');
				return $query->result_array();
			}
			$this->db->order_by('advertisements.id', 'DESC');

			$this->db->join('prices', 'prices.id = advertisements.price_id');
			$this->db->join('customers', 'customers.id_cus = advertisements.customer_id');

			$query = $this->db->get_where('advertisements', array('slug' => $slug));
			return $query->row_array();
		}

		public function get_advertisements_new(){
			$this->db->order_by('advertisements.id', 'DESC');

			$this->db->join('prices', 'prices.id = advertisements.price_id');
			$this->db->join('customers', 'customers.id_cus = advertisements.customer_id');

			$query = $this->db->get_where('advertisements', array('ads_status' => 0));
			return $query->result_array();
		}

		public function get_promotes_new(){
			$this->db->order_by('promotes.id', 'DESC');

			$this->db->join('advertisements', 'advertisements.id = promotes.advertisement_id');
			$this->db->join('instagrammers', 'instagrammers.id_ins = promotes.instagrammer_id');

			$query = $this->db->get_where('promotes', array('promotes.prm_status' => 0));
			return $query->result_array();
		}

		public function get_advertisements_all($slug = FALSE){

			if($slug === FALSE){
				$this->db->order_by('advertisements.id', 'DESC');

				$this->db->join('prices', 'prices.id = advertisements.price_id');
				$this->db->join('customers', 'customers.id_cus = advertisements.customer_id');

				$query = $this->db->get_where('advertisements', array('ads_status' => 1));
				return $query->result_array();
			}

			$this->db->join('prices', 'prices.id = advertisements.price_id');
			$this->db->join('customers', 'customers.id_cus = advertisements.customer_id');

			$query = $this->db->get_where('advertisements', array('ads_status' => 1,'slug' => $slug));
			return $query->row_array();
		}

		public function get_advertisements_by_instagrammer_new($slug){

			$this->db->join('promotes', 'promotes.advertisement_id	= advertisements.id');
			$this->db->join('prices', 'advertisements.price_id	= prices.id');
			$this->db->join('instagrammers', 'promotes.instagrammer_id	= instagrammers.id_ins');
			$this->db->join('customers', 'advertisements.customer_id = customers.id_cus');

			$query = $this->db->get_where('advertisements', array('ads_status' => 1,'prm_status' => 0, 'slug'=> $slug));
			return $query->result_array();
		}

		public function get_advertisements_by_instagrammer($slug){

			$this->db->join('promotes', 'promotes.advertisement_id	= advertisements.id');
			$this->db->join('prices', 'advertisements.price_id	= prices.id');
			$this->db->join('instagrammers', 'promotes.instagrammer_id	= instagrammers.id_ins');
			$this->db->join('customers', 'advertisements.customer_id = customers.id_cus');

			$query = $this->db->get_where('advertisements', array('ads_status' => 1,'prm_status'=> 1 , 'slug'=> $slug));
			return $query->result_array();
		}

		public function sum_advertisements_all(){
			$query = $this->db->get_where('advertisements', array('ads_status' => 1));
			
			$data  = $query->num_rows();
			return $data;
		}

		// Update Customer
		public function active_advertisement($slug){
			// Customer data array
			$data = array(
				'ads_status' => 1
			);

			// Query Update Customer
			$this->db->where('slug', $slug);
			return $this->db->update('advertisements', $data);
		}

		// Delete Advertisement
		public function delete_advertisement($slug){

			//Delete Customer
			$this->db->where('slug', $slug);
			$this->db->delete('advertisements');
			return true;
		}

		//create advertisement
		public function create_promotes(){

			$data = array(
				'advertisement_id' => $this->input->post('advertisement_id'),
				'instagrammer_id' => $this->session->userdata('id_ins'),
				'point' => 10,
				'url' => $this->input->post('url_post'),
				'prm_status' => 0
			);

			return $this->db->insert('promotes', $data);
		}

		// Delete Advertisement
		public function delete_promotes($id){

			//Delete Customer
			$this->db->where('instagrammer_id', $id);
			$this->db->delete('promotes');
			return true;
		}

		// Delete Advertisement
		public function confirm_promotes($id){
			// Promotes data array
			$data = array(
				'prm_status' => 1
			);

			// Query Update Customer
			$this->db->where('instagrammer_id', $id);
			return $this->db->update('promotes', $data);
		}
	}

?>
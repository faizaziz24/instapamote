<?php 
	class Advertisements extends CI_Controller{
		
		public function index(){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$data['title'] = 'New Advertisement';

			$data['advertisements'] = $this->advertisement_model->get_advertisements_new();

			$this->load->view('admin/templates/header', $data);
			$this->load->view('admin/templates/sidebar');
			$this->load->view('admin/advertisements/index', $data);
			$this->load->view('admin/templates/footer');
		}

		public function report(){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$data['title'] = 'Report Advertisement';

			$data['advertisements'] = $this->advertisement_model->get_advertisements_all();

			$this->load->view('admin/templates/header', $data);
			$this->load->view('admin/templates/sidebar');
			$this->load->view('admin/advertisements/report', $data);
			$this->load->view('admin/templates/footer');
		}

		public function view($slug = NULL){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$data['advertisements'] = $this->advertisement_model->get_advertisements_all($slug);

			$data['promotes'] = $this->advertisement_model->get_advertisements_by_instagrammer($slug);


			if(empty($data['advertisements'])){
				show_404();
			}

			$data['title'] = 'View Advertisement';

			$this->load->view('admin/templates/header', $data);
			$this->load->view('admin/templates/sidebar');
			$this->load->view('admin/advertisements/view', $data);
			$this->load->view('admin/templates/footer');
		}

		// Active Advertisement
		public function active($slug){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}
			
			$this->advertisement_model->active_advertisement($slug);

			// Set message
			$this->session->set_flashdata('advertisement_actived', 'Your Advertisement has been actived');

			redirect('admin/advertisements');
		}


		// Delete Advertisement
		public function delete($slug){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$this->advertisement_model->delete_advertisement($slug);

			// Set message
			$this->session->set_flashdata('advertisement_deleted', 'Your advertisement has been deleted');

			redirect('admin/advertisements');
		}
	}

?>
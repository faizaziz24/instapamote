<?php 
	class Instagrammers extends CI_Controller{

		public function dashboard(){
			if(!$this->session->userdata('instagrammer_logged_in')){
				redirect('instagrammer/register');
			}

			$data['title'] = 'Dashboard Instagrammer';

			$data['promotes'] = $this->instagrammer_model->get_promotes_all();

			$this->load->view('templates/header', $data);
			$this->load->view('templates/navbar');
			$this->load->view('instagrammers/dashboard', $data);
			$this->load->view('templates/footer');
		}

		public function register(){
			$data['title'] = 'Register Instagrammer';

			$this->form_validation->set_rules('name', 'Name', 'required');
			$this->form_validation->set_rules('email', 'Email', 'required|callback_check_email_exists');
			$this->form_validation->set_rules('url', 'Url Profile', 'required|callback_check_url_exists');
			$this->form_validation->set_rules('password', 'Password', 'required');
			$this->form_validation->set_rules('password2', 'Confirm Password', 'matches[password]');

			if($this->form_validation->run() === FALSE){
				$this->load->view('templates/header', $data);
				$this->load->view('templates/navbar');
				$this->load->view('instagrammers/register', $data);
				$this->load->view('templates/footer');
			} else {
				$enc_password = md5($this->input->post('password'));

				$this->instagrammer_model->register($enc_password);

				$this->session->set_flashdata('instagrammer_registered', 'You are now registered and can log in');

				redirect('instagrammers/register');
			}
		}

		// Log in instagrammer
		public function login(){
			$data['title'] = 'Login Instagrammer';

			$this->form_validation->set_rules('email', 'Email', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required');

			if($this->form_validation->run() === FALSE){
				$this->load->view('templates/header', $data);
				$this->load->view('templates/navbar');
				$this->load->view('instagrammers/login', $data);
				$this->load->view('templates/footer');
			} else {
				
				// Get email
				$email = $this->input->post('email');
				// Get and encrypt the password
				$password = md5($this->input->post('password'));

				// Login instagrammer
				$id_ins = $this->instagrammer_model->login($email, $password);

				if($id_ins){
					// Create session
					$instagrammer_data = array(
						'id_ins' => $id_ins,
						'instagrammer_logged_in' => true
					);

					$this->session->set_userdata($instagrammer_data);

					// Set message
					$this->session->set_flashdata('instagrammer_loggedin', 'You are now logged in');

					redirect('instagrammers/dashboard');
				} else {
					// Set message
					$this->session->set_flashdata('login_failed', 'Login is invalid');

					redirect('instagrammers/login');
				}		
			}
		}

		// Log instagrammer out
		public function logout(){
			// Unset instagrammer data
			$this->session->unset_userdata('instagrammer_logged_in');
			$this->session->unset_userdata('id_ins');
			$this->session->unset_userdata('name_ins');
			$this->session->unset_userdata('email_ins');
			$this->session->unset_userdata('url_profile_ins');
			$this->session->unset_userdata('point');


			// Set message
			$this->session->set_flashdata('instagrammer_loggedout', 'You are now logged out');

			redirect('instagrammers/login');
		}

		// Check if email exists
		public function check_email_exists($email){
			$this->form_validation->set_message('check_email_exists', 'That email is taken. Please choose a different one');
			if($this->instagrammer_model->check_email_exists($email)){
				return true;
			} else {
				return false;
			}
		}

		// Check if url profile exists
		public function check_url_exists($url){
			$this->form_validation->set_message('check_url_exists', 'That url profile is taken. Please choose a different one');
			if($this->instagrammer_model->check_url_exists($url)){
				return true;
			} else {
				return false;
			}
		}
	}
?>
<?php 
	class Customers extends CI_Controller{
		
		public function index(){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$data['title'] = 'New Customers';

			$data['customers'] = $this->customer_model->get_customers_new();

			$this->load->view('admin/templates/header', $data);
			$this->load->view('admin/templates/sidebar');
			$this->load->view('admin/customers/index', $data);
			$this->load->view('admin/templates/footer');
		}

		public function report(){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$data['title'] = 'Report Customer';

			$data['customers'] = $this->customer_model->get_customers_all();

			$this->load->view('admin/templates/header', $data);
			$this->load->view('admin/templates/sidebar');
			$this->load->view('admin/customers/report', $data);
			$this->load->view('admin/templates/footer');
		}

		public function create(){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$data['title'] = 'Create Customer';

			$this->form_validation->set_rules('name', 'Name', 'required');
			$this->form_validation->set_rules('email', 'Email', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required');
			$this->form_validation->set_rules('password2', 'Confirm Password', 'matches[password]');


			if($this->form_validation->run() === FALSE){
				$this->load->view('admin/templates/header', $data);
				$this->load->view('admin/templates/sidebar');
				$this->load->view('admin/customers/create', $data);
				$this->load->view('admin/templates/footer');
			} else {
				// Encrypt password
				$enc_password = md5($this->input->post('password'));

				$this->customer_model->create($enc_password);

				// Set message
				$this->session->set_flashdata('customer_created', 'You are now created');

				redirect('admin/customers');
			}
		}

		public function edit($id){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$data['customer'] = $this->customer_model->get_customers($id);

			if(empty($data['customer'])){
				show_404();
			}

			$data['title'] = 'Update Customer';

			$this->form_validation->set_rules('name', 'Name', 'required');
			$this->form_validation->set_rules('email', 'Email', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required');

			$this->load->view('admin/templates/header', $data);
			$this->load->view('admin/templates/sidebar');
			$this->load->view('admin/customers/edit', $data);
			$this->load->view('admin/templates/footer');


		}

		public function update(){
			// Check login
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$enc_password = md5($this->input->post('password'));

			$this->customer_model->update_customer($enc_password);

			// Set message
			$this->session->set_flashdata('customer_updated', 'Your customer has been updated');

			redirect('admin/customers/report');
		}

		// Active Customer
		public function active($id){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}
			
			$this->customer_model->active_customer($id);

			// Set message
			$this->session->set_flashdata('customer_actived', 'Your customer has been actived');

			redirect('admin/customers');
		}

		// Delete Customer
		public function delete($id){
			if(!$this->session->userdata('admin_logged_in')){
				redirect('');
			}

			$this->customer_model->delete_customer($id);

			// Set message
			$this->session->set_flashdata('customer_deleted', 'Your customer has been deleted');

			redirect('admin/customers');
		}

		// Check if email exists
		public function check_email_exists($email){
			$this->form_validation->set_message('check_email_exists', 'That email is taken. Please choose a different one');
			if($this->customer_model->check_email_exists($email)){
				return true;
			} else {
				return false;
			}
		}


	}

?>
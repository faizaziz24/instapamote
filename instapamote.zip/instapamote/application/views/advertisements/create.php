<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Create Promote 				
							</h1>	
							<p class="text-white link-nav"><a href="<?php echo base_url(); ?>advertisements"> Advertisement</a></a>  <span class="lnr lnr-arrow-right"></span> Confirmation</p>
						</div>											
					</div>
				</div>
			</section>
			<!-- End banner Area -->
			<!-- Start post Area -->
			<section class="post-area section-gap">
				<div class="container">
					<div class="row justify-content-center d-flex">
						<div class="post-list">
							<div class="single-post d-flex flex-row">
								<div class="col-lg-2 feat-img no-padding" style="margin-right: 15px;">
									<div class="thumb" style="margin-right: 15px;">
										<img src="<?php echo site_url(); ?>assets/img/advertisements/<?php echo $advertisements['photo']; ?>" alt="">
									</div>
								</div>
								<div class="col-lg-10">
									<div class="details">
										<div class="title d-flex flex-row justify-content-between">
											<div class="titles">
												<a href=""><h4><?php echo $advertisements['title']; ?></h4></a>
												<h6>Created on : <?php echo $advertisements['create_at']; ?></h6>
												<!-- Name area -->
												<!-- <h6>By : <?php echo $advertisement['name_cus']; ?></h6> -->					
											</div>
										</div>
										<p>
											Description : <?php echo $advertisements['description']; ?>
										</p>
									</div>
								</div>
							</div>
							<div class="sidebar">
								<div class="single-slidebar">
									<div class="titles">
										<h4>Confirmation</h4>
										<p>
										Confirm for promotion the product/event
										</p>				
									</div>
									<?php echo form_open('advertisements/create'); ?>
										<div class="form-group">
											<input type="text" name="url_post" class="form-control" placeholder="ex: https://www.instagram.com/lngacademy/SaqwE25erRa">
										</div>
										<div class="input-group-icon mt-40 text-center">
											<input type="hidden" name="advertisement_id" value="<?php echo $advertisements['id']; ?>">
											<input type="submit" value="Confirm" class="genric-btn primary radius default">
										</div>
									<?php echo form_close(); ?>
								</div>	
							</div>	
						</div>
					</div>
				</div>
			</section>
<?php 
	class Advertisements extends CI_Controller{
		
		public function index(){
			$data['title'] = 'Latest Advertisements';

			$data['advertisements'] = $this->advertisement_model->get_advertisement_promote();

			$this->load->view('templates/header', $data);
			$this->load->view('templates/navbar');
			$this->load->view('advertisements/index', $data);
			$this->load->view('templates/footer');
		}

		public function create($id = NULL){
			if(!$this->session->userdata('instagrammer_logged_in')){
				redirect('instagrammer/register');
			}

			$data['title'] = 'Create promote';

			$data['advertisements'] = $this->advertisement_model->get_advertisement_promote($id);

			$this->form_validation->set_rules('url_post', 'URL Post', 'required');

			if($this->form_validation->run() === FALSE){

				$this->load->view('templates/header', $data);
				$this->load->view('templates/navbar');
				$this->load->view('advertisements/create', $data);
				$this->load->view('templates/footer');
			} else {

				$this->advertisement_model->create_promotes($id);

				$this->session->set_flashdata('create_promoted', 'Your promoted has been created');

				redirect('instagrammers/dashboard');
			}
		}

		public function view($slug = NULL){
			if(!$this->session->userdata('customer_logged_in')){
				redirect('customers/register');
			}

			$data['title'] = 'View Advertisement';

			$data['advertisements'] = $this->advertisement_model->get_advertisements_all($slug);

			$data['promotes'] = $this->advertisement_model->get_advertisements_by_instagrammer_new($slug);

			if(empty($data['advertisements'])){
				show_404();
			}

			$this->load->view('templates/header', $data);
			$this->load->view('templates/navbar');
			$this->load->view('customers/view', $data);
			$this->load->view('templates/footer');
		}

		// Delete Customer
		public function delete($id){
			if(!$this->session->userdata('customer_logged_in')){
				redirect('customers/register');
			}

			$this->advertisement_model->delete_promotes($id);

			// Set message
			$this->session->set_flashdata('promotes_deleted', 'Your promotes has been deleted');

			redirect('customers/dashboard');
		}

		// Delete Customer
		public function confirm($id){
			if(!$this->session->userdata('customer_logged_in')){
				redirect('customers/register');
			}

			$this->advertisement_model->confirm_promotes($id);

			// Set message
			$this->session->set_flashdata('promotes_confirmed', 'Your promotes has been confirmed');

			redirect('customers/dashboard');
		}
	}

?>